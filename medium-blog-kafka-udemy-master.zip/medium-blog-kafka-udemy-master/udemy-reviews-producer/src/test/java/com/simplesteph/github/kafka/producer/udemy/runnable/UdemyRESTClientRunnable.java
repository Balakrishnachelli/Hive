package com.simplesteph.github.kafka.producer.udemy.runnable;

public class UdemyRESTClientRunnable {
}
